--
-- Database: `space_truckin`
--
CREATE DATABASE IF NOT EXISTS `space_truckin` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `space_truckin`;

-- --------------------------------------------------------

--
-- Table structure for table `cargo`
--

CREATE TABLE `cargo` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `id_tradegoods` int(11) DEFAULT NULL,
  `id_ship` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cargo`
--

INSERT INTO `cargo` (`id`, `id_tradegoods`, `id_ship`, `quantity`) VALUES
(105, 1, 13, 0),
(106, 2, 13, 0),
(107, 3, 13, 0),
(108, 4, 13, 0),
(109, 5, 13, 0),
(110, 6, 13, 0),
(111, 7, 13, 0),
(112, 8, 13, 0),
(113, 1, 14, 0),
(114, 2, 14, 0),
(115, 3, 14, 0),
(116, 4, 14, 0),
(117, 5, 14, 0),
(118, 6, 14, 0),
(119, 7, 14, 0),
(120, 8, 14, 0),
(121, 1, 15, 0),
(122, 2, 15, 13),
(123, 3, 15, 0),
(124, 4, 15, 0),
(125, 5, 15, 0),
(126, 6, 15, 0),
(127, 7, 15, 0),
(128, 8, 15, 0),
(129, 1, 16, 0),
(130, 2, 16, 0),
(131, 3, 16, 0),
(132, 4, 16, 0),
(133, 5, 16, 0),
(134, 6, 16, 0),
(135, 7, 16, 0),
(136, 8, 16, 0),
(137, 1, 17, 0),
(138, 2, 17, 0),
(139, 3, 17, 0),
(140, 4, 17, 0),
(141, 5, 17, 0),
(142, 6, 17, 0),
(143, 7, 17, 0),
(144, 8, 17, 0),
(145, 1, 18, 0),
(146, 2, 18, 0),
(147, 3, 18, 0),
(148, 4, 18, 0),
(149, 5, 18, 0),
(150, 6, 18, 37),
(151, 7, 18, 0),
(152, 8, 18, 0),
(153, 1, 19, 50),
(154, 2, 19, 0),
(155, 3, 19, 49),
(156, 4, 19, 0),
(157, 5, 19, 0),
(158, 6, 19, 0),
(159, 7, 19, 0),
(160, 8, 19, 0),
(161, 1, 20, 0),
(162, 2, 20, 0),
(163, 3, 20, 0),
(164, 4, 20, 0),
(165, 5, 20, 22),
(166, 6, 20, 35),
(167, 7, 20, 0),
(168, 8, 20, 43),
(169, 1, 21, 0),
(170, 2, 21, 0),
(171, 3, 21, 0),
(172, 4, 21, 0),
(173, 5, 21, 0),
(174, 6, 21, 0),
(175, 7, 21, 0),
(176, 8, 21, 0),
(177, 1, 22, 0),
(178, 2, 22, 0),
(179, 3, 22, 0),
(180, 4, 22, 0),
(181, 5, 22, 0),
(182, 6, 22, 0),
(183, 7, 22, 0),
(184, 8, 22, 0);

-- --------------------------------------------------------

--
-- Table structure for table `high_scores`
--

CREATE TABLE `high_scores` (
  `ship_name` varchar(255) DEFAULT NULL,
  `score` int(11) DEFAULT NULL,
  `id` bigint(20) UNSIGNED NOT NULL,
  `turn` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `high_scores`
--

INSERT INTO `high_scores` (`ship_name`, `score`, `id`, `turn`) VALUES
('Beowulf', 452, 1, 45),
('Serenity', 768, 2, 45),
('Apollo 11', -45, 3, 45),
('Ship Seven', 94000, 4, 45),
('Back to space', 99500, 5, 3),
('Please!!', 99750, 8, 2),
('Work', 90587, 9, 39),
('Testing', 81680, 10, 5),
('beowulf', 36825, 11, 4),
('test', 49000, 12, 2),
('test', 155810, 13, 38);

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `id_planets` int(11) DEFAULT NULL,
  `id_tradegoods` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`id`, `id_planets`, `id_tradegoods`, `quantity`, `price`) VALUES
(3985, 5, 1, 57, 17),
(3986, 5, 2, 0, 39),
(3987, 5, 3, 0, 62),
(3988, 5, 4, 0, 64),
(3989, 5, 5, 65, 151),
(3990, 5, 6, 0, 259),
(3991, 5, 7, 0, 387),
(3992, 5, 8, 0, 166),
(3993, 8, 1, 66, 159),
(3994, 8, 2, 0, 255),
(3995, 8, 3, 0, 248),
(3996, 8, 4, 0, 201),
(3997, 8, 5, 0, 148),
(3998, 8, 6, 0, 273),
(3999, 8, 7, 43, 88),
(4000, 8, 8, 0, 174),
(4001, 10, 1, 0, 60),
(4002, 10, 2, 0, 63),
(4003, 10, 3, 0, 84),
(4004, 10, 4, 0, 155),
(4005, 10, 5, 0, 51),
(4006, 10, 6, 0, 113),
(4007, 10, 7, 16, 85),
(4008, 10, 8, 18, 43),
(4009, 16, 1, 0, 229),
(4010, 16, 2, 0, 118),
(4011, 16, 3, 0, 158),
(4012, 16, 4, 0, 172),
(4013, 16, 5, 51, 40),
(4014, 16, 6, 0, 192),
(4015, 16, 7, 31, 167),
(4016, 16, 8, 0, 136),
(4017, 17, 1, 0, 84),
(4018, 17, 2, 18, 72),
(4019, 17, 3, 0, 171),
(4020, 17, 4, 0, 112),
(4021, 17, 5, 0, 71),
(4022, 17, 6, 0, 95),
(4023, 17, 7, 0, 105),
(4024, 17, 8, 15, 27),
(4025, 19, 1, 0, 34),
(4026, 19, 2, 65, 24),
(4027, 19, 3, 29, 18),
(4028, 19, 4, 0, 55),
(4029, 19, 5, 0, 118),
(4030, 19, 6, 0, 164),
(4031, 19, 7, 0, 167),
(4032, 19, 8, 0, 211),
(4033, 22, 1, 0, 145),
(4034, 22, 2, 99, 161),
(4035, 22, 3, 0, 191),
(4036, 22, 4, 0, 389),
(4037, 22, 5, 38, 45),
(4038, 22, 6, 0, 279),
(4039, 22, 7, 0, 223),
(4040, 22, 8, 0, 202),
(4041, 27, 1, 58, 33),
(4042, 27, 2, 0, 30),
(4043, 27, 3, 0, 54),
(4044, 27, 4, 26, 14),
(4045, 27, 5, 0, 114),
(4046, 27, 6, 0, 186),
(4047, 27, 7, 0, 170),
(4048, 27, 8, 0, 224),
(4049, 30, 1, 79, 165),
(4050, 30, 2, 0, 324),
(4051, 30, 3, 0, 208),
(4052, 30, 4, 0, 258),
(4053, 30, 5, 0, 172),
(4054, 30, 6, 0, 242),
(4055, 30, 7, 37, 106),
(4056, 30, 8, 0, 193),
(4057, 36, 1, 0, 30),
(4058, 36, 2, 16, 26),
(4059, 36, 3, 18, 9),
(4060, 36, 4, 0, 23),
(4061, 36, 5, 0, 73),
(4062, 36, 6, 0, 121),
(4063, 36, 7, 0, 88),
(4064, 36, 8, 0, 155),
(4065, 38, 1, 0, 25),
(4066, 38, 2, 16, 9),
(4067, 38, 3, 0, 40),
(4068, 38, 4, 0, 35),
(4069, 38, 5, 17, 76),
(4070, 38, 6, 0, 188),
(4071, 38, 7, 0, 86),
(4072, 38, 8, 0, 70),
(4073, 40, 1, 0, 36),
(4074, 40, 2, 52, 30),
(4075, 40, 3, 0, 53),
(4076, 40, 4, 45, 19),
(4077, 40, 5, 0, 118),
(4078, 40, 6, 0, 178),
(4079, 40, 7, 0, 161),
(4080, 40, 8, 0, 292),
(4081, 43, 1, 0, 60),
(4082, 43, 2, 0, 49),
(4083, 43, 3, 35, 15),
(4084, 43, 4, 0, 52),
(4085, 43, 5, 0, 161),
(4086, 43, 6, 91, 231),
(4087, 43, 7, 0, 234),
(4088, 43, 8, 0, 317),
(4089, 46, 1, 0, 134),
(4090, 46, 2, 0, 112),
(4091, 46, 3, 76, 143),
(4092, 46, 4, 0, 342),
(4093, 46, 5, 0, 106),
(4094, 46, 6, 0, 182),
(4095, 46, 7, 0, 150),
(4096, 46, 8, 33, 48),
(4097, 53, 1, 0, 23),
(4098, 53, 2, 0, 27),
(4099, 53, 3, 17, 24),
(4100, 53, 4, 19, 8),
(4101, 53, 5, 0, 66),
(4102, 53, 6, 0, 138),
(4103, 53, 7, 0, 150),
(4104, 53, 8, 0, 88),
(4105, 54, 1, 0, 163),
(4106, 54, 2, 0, 85),
(4107, 54, 3, 0, 91),
(4108, 54, 4, 0, 109),
(4109, 54, 5, 0, 59),
(4110, 54, 6, 0, 88),
(4111, 54, 7, 17, 117),
(4112, 54, 8, 18, 31),
(4113, 68, 1, 0, 33),
(4114, 68, 2, 0, 53),
(4115, 68, 3, 0, 63),
(4116, 68, 4, 25, 20),
(4117, 68, 5, 0, 137),
(4118, 68, 6, 81, 254),
(4119, 68, 7, 0, 396),
(4120, 68, 8, 0, 213),
(4121, 69, 1, 14, 23),
(4122, 69, 2, 0, 12),
(4123, 69, 3, 23, 8),
(4124, 69, 4, 0, 38),
(4125, 69, 5, 0, 67),
(4126, 69, 6, 0, 105),
(4127, 69, 7, 0, 185),
(4128, 69, 8, 0, 74),
(4129, 73, 1, 0, 127),
(4130, 73, 2, 0, 222),
(4131, 73, 3, 0, 163),
(4132, 73, 4, 0, 170),
(4133, 73, 5, 47, 43),
(4134, 73, 6, 0, 179),
(4135, 73, 7, 50, 166),
(4136, 73, 8, 0, 144),
(4137, 85, 1, 0, 132),
(4138, 85, 2, 0, 116),
(4139, 85, 3, 0, 233),
(4140, 85, 4, 0, 161),
(4141, 85, 5, 38, 119),
(4142, 85, 6, 0, 177),
(4143, 85, 7, 45, 43),
(4144, 85, 8, 0, 138),
(4145, 88, 1, 0, 141),
(4146, 88, 2, 115, 154),
(4147, 88, 3, 0, 209),
(4148, 88, 4, 0, 308),
(4149, 88, 5, 0, 169),
(4150, 88, 6, 25, 90),
(4151, 88, 7, 0, 254),
(4152, 88, 8, 0, 197),
(4153, 99, 1, 21, 6),
(4154, 99, 2, 14, 21),
(4155, 99, 3, 0, 26),
(4156, 99, 4, 0, 31),
(4157, 99, 5, 0, 87),
(4158, 99, 6, 0, 113),
(4159, 99, 7, 0, 229),
(4160, 99, 8, 0, 85);

-- --------------------------------------------------------

--
-- Table structure for table `parameters`
--

CREATE TABLE `parameters` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(128) DEFAULT NULL,
  `value` int(11) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `parameters`
--

INSERT INTO `parameters` (`id`, `name`, `value`, `type`) VALUES
(1, 'pop_1_max_inventory', 30, 'max_inventory'),
(2, 'pop_2_max_inventory', 75, 'max_inventory'),
(3, 'pop_3_max_inventory', 100, 'max_inventory'),
(4, 'type_match_min_factor', 25, 'type_factor'),
(5, 'type_match_max_factor', 50, 'type_factor'),
(6, 'type_mismatch_min_factor', 125, 'type_factor'),
(7, 'type_mismatch_max_factor', 150, 'type_factor'),
(8, 'pop_1_min_factor', 50, 'pop_factor'),
(9, 'pop_1_max_factor', 75, 'pop_factor'),
(10, 'pop_2_min_factor', 100, 'pop_factor'),
(11, 'pop_2_max_factor', 100, 'pop_factor'),
(12, 'pop_3_min_factor', 125, 'pop_factor'),
(13, 'pop_3_max_factor', 150, 'pop_factor'),
(14, 'specialty_min_factor', 25, 'specialty_factor'),
(15, 'specialty_max_factor', 50, 'specialty_factor'),
(16, 'controlled_min_factor', 150, 'controlled_factor'),
(17, 'controlled_max_factor', 200, 'controlled_factor'),
(18, 'min_planet_density', 28, 'system_setup'),
(19, 'max_planet_density', 35, 'system_setup'),
(20, 'universe_size_sqrt', 10, 'system_setup'),
(21, 'ag_planet_share', 35, 'system_setup'),
(22, 'in_planet_share', 35, 'system_setup'),
(23, 'fuel_planet_share', 30, 'system_setup'),
(24, 'inventory_increment_min_percent', 25, 'increment_percent'),
(25, 'inventory_increment_max_percent', 50, 'increment_percent'),
(26, 'increment_specialty_share', 33, 'increment_percent'),
(27, 'increment_regular_share', 67, 'increment_percent'),
(28, 'fuel_price', 10, 'gameplay'),
(29, 'max_fuel', 100, 'gameplay'),
(30, 'starting_fuel', 80, 'gameplay'),
(31, 'max_cargo', 100, 'gameplay'),
(32, 'starting_credits', 10000, 'gameplay'),
(33, 'starting_x', 3, 'gameplay'),
(34, 'starting_y', 3, 'gameplay'),
(35, 'max_turns', 50, 'gameplay'),
(36, 'upkeep_cost', 1000, 'gameplay'),
(37, 'travel_cost', 10, 'gameplay');

-- --------------------------------------------------------

--
-- Table structure for table `planets`
--

CREATE TABLE `planets` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `type` int(11) DEFAULT NULL,
  `population` int(11) DEFAULT NULL,
  `location_x` int(11) DEFAULT NULL,
  `location_y` int(11) DEFAULT NULL,
  `specialty` int(11) DEFAULT NULL,
  `controlled` int(11) DEFAULT NULL,
  `regular` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `planets`
--

INSERT INTO `planets` (`id`, `type`, `population`, `location_x`, `location_y`, `specialty`, `controlled`, `regular`, `name`) VALUES
(1, 0, 0, 1, 1, 0, 0, 0, ''),
(2, 0, 0, 1, 2, 0, 0, 0, ''),
(3, 0, 0, 1, 3, 0, 0, 0, ''),
(4, 0, 0, 1, 4, 0, 0, 0, ''),
(5, 1, 3, 1, 5, 1, 7, 5, 'Goeria'),
(6, 0, 0, 1, 6, 0, 0, 0, ''),
(7, 0, 0, 1, 7, 0, 0, 0, ''),
(8, 2, 3, 1, 8, 7, 2, 1, 'Wheshan OEP'),
(9, 0, 0, 1, 9, 0, 0, 0, ''),
(10, 2, 1, 1, 10, 8, 4, 7, 'Strade TD'),
(11, 0, 0, 2, 1, 0, 0, 0, ''),
(12, 0, 0, 2, 2, 0, 0, 0, ''),
(13, 0, 0, 2, 3, 0, 0, 0, ''),
(14, 0, 0, 2, 4, 0, 0, 0, ''),
(15, 0, 0, 2, 5, 0, 0, 0, ''),
(16, 2, 2, 2, 6, 5, 1, 7, 'Blichi WMOE'),
(17, 2, 1, 2, 7, 8, 3, 2, 'Kathiuq'),
(18, 0, 0, 2, 8, 0, 0, 0, ''),
(19, 1, 2, 2, 9, 3, 8, 2, 'Goeria'),
(20, 0, 0, 2, 10, 0, 0, 0, ''),
(21, 0, 0, 3, 1, 0, 0, 0, ''),
(22, 2, 3, 3, 2, 5, 4, 2, 'Gacrorth'),
(23, 0, 0, 3, 3, 0, 0, 0, ''),
(24, 0, 0, 3, 4, 0, 0, 0, ''),
(25, 0, 0, 3, 5, 0, 0, 0, ''),
(26, 0, 0, 3, 6, 0, 0, 0, ''),
(27, 1, 2, 3, 7, 4, 8, 1, 'Frufawei'),
(28, 0, 0, 3, 8, 0, 0, 0, ''),
(29, 3, 0, 3, 9, 0, 0, 0, 'Negawa'),
(30, 2, 3, 3, 10, 7, 2, 1, 'Gretothea'),
(31, 0, 0, 4, 1, 0, 0, 0, ''),
(32, 0, 0, 4, 2, 0, 0, 0, ''),
(33, 0, 0, 4, 3, 0, 0, 0, ''),
(34, 0, 0, 4, 4, 0, 0, 0, ''),
(35, 0, 0, 4, 5, 0, 0, 0, ''),
(36, 1, 1, 4, 6, 3, 8, 2, 'Yasmuihines'),
(37, 0, 0, 4, 7, 0, 0, 0, ''),
(38, 1, 1, 4, 8, 2, 6, 5, 'Tabreyhiri'),
(39, 0, 0, 4, 9, 0, 0, 0, ''),
(40, 1, 2, 4, 10, 4, 8, 2, 'Aenerth'),
(41, 3, 0, 5, 1, 0, 0, 0, 'Powhadus'),
(42, 0, 0, 5, 2, 0, 0, 0, ''),
(43, 1, 3, 5, 3, 3, 8, 6, 'Crarvis 4'),
(44, 0, 0, 5, 4, 0, 0, 0, ''),
(45, 0, 0, 5, 5, 0, 0, 0, ''),
(46, 2, 2, 5, 6, 8, 4, 3, 'Xusmiuruta'),
(47, 0, 0, 5, 7, 0, 0, 0, ''),
(48, 0, 0, 5, 8, 0, 0, 0, ''),
(49, 0, 0, 5, 9, 0, 0, 0, ''),
(50, 3, 0, 5, 10, 0, 0, 0, 'Seylia'),
(51, 0, 0, 6, 1, 0, 0, 0, ''),
(52, 0, 0, 6, 2, 0, 0, 0, ''),
(53, 1, 1, 6, 3, 4, 7, 3, 'Vophus'),
(54, 2, 1, 6, 4, 8, 1, 7, 'Echoyhines'),
(55, 0, 0, 6, 5, 0, 0, 0, ''),
(56, 3, 0, 6, 6, 0, 0, 0, 'Iahines'),
(57, 3, 0, 6, 7, 0, 0, 0, 'Peshippe'),
(58, 0, 0, 6, 8, 0, 0, 0, ''),
(59, 0, 0, 6, 9, 0, 0, 0, ''),
(60, 0, 0, 6, 10, 0, 0, 0, ''),
(61, 0, 0, 7, 1, 0, 0, 0, ''),
(62, 0, 0, 7, 2, 0, 0, 0, ''),
(63, 0, 0, 7, 3, 0, 0, 0, ''),
(64, 0, 0, 7, 4, 0, 0, 0, ''),
(65, 0, 0, 7, 5, 0, 0, 0, ''),
(66, 0, 0, 7, 6, 0, 0, 0, ''),
(67, 3, 0, 7, 7, 0, 0, 0, 'Maswov'),
(68, 1, 3, 7, 8, 4, 7, 6, 'Glomia 02A'),
(69, 1, 1, 7, 9, 3, 7, 1, 'Slaeruta'),
(70, 0, 0, 7, 10, 0, 0, 0, ''),
(71, 0, 0, 8, 1, 0, 0, 0, ''),
(72, 0, 0, 8, 2, 0, 0, 0, ''),
(73, 2, 2, 8, 3, 5, 2, 7, 'Foynus'),
(74, 0, 0, 8, 4, 0, 0, 0, ''),
(75, 0, 0, 8, 5, 0, 0, 0, ''),
(76, 0, 0, 8, 6, 0, 0, 0, ''),
(77, 3, 0, 8, 7, 0, 0, 0, 'Gretothea'),
(78, 3, 0, 8, 8, 0, 0, 0, 'Whiea A07'),
(79, 0, 0, 8, 9, 0, 0, 0, ''),
(80, 0, 0, 8, 10, 0, 0, 0, ''),
(81, 0, 0, 9, 1, 0, 0, 0, ''),
(82, 0, 0, 9, 2, 0, 0, 0, ''),
(83, 0, 0, 9, 3, 0, 0, 0, ''),
(84, 0, 0, 9, 4, 0, 0, 0, ''),
(85, 2, 2, 9, 5, 7, 3, 5, 'Askeron'),
(86, 0, 0, 9, 6, 0, 0, 0, ''),
(87, 0, 0, 9, 7, 0, 0, 0, ''),
(88, 2, 3, 9, 8, 6, 4, 2, 'Deproilara'),
(89, 0, 0, 9, 9, 0, 0, 0, ''),
(90, 0, 0, 9, 10, 0, 0, 0, ''),
(91, 0, 0, 10, 1, 0, 0, 0, ''),
(92, 3, 0, 10, 2, 0, 0, 0, 'Peshippe'),
(93, 0, 0, 10, 3, 0, 0, 0, ''),
(94, 0, 0, 10, 4, 0, 0, 0, ''),
(95, 0, 0, 10, 5, 0, 0, 0, ''),
(96, 0, 0, 10, 6, 0, 0, 0, ''),
(97, 0, 0, 10, 7, 0, 0, 0, ''),
(98, 0, 0, 10, 8, 0, 0, 0, ''),
(99, 1, 1, 10, 9, 1, 7, 2, 'Maswov'),
(100, 0, 0, 10, 10, 0, 0, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `planet_names`
--

CREATE TABLE `planet_names` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `planet_names`
--

INSERT INTO `planet_names` (`id`, `name`) VALUES
(1, 'Odriulia'),
(2, 'Echoyhines'),
(3, 'Vobrarth'),
(4, 'Eslion'),
(5, 'Peyter'),
(6, 'Yiylia'),
(7, 'Gretothea'),
(8, 'Slamanus'),
(9, 'Treron NQ5'),
(10, 'Trore HU'),
(11, 'Tusneinus'),
(12, 'Deproilara'),
(13, 'Maswov'),
(14, 'Gacrorth'),
(15, 'Mopra'),
(16, 'Xuagantu'),
(17, 'Brusoclite'),
(18, 'Snegunides'),
(19, 'Shurn 3G17'),
(20, 'Scilia 48'),
(21, 'Cestreter'),
(22, 'Fawhauter'),
(23, 'Hosnora'),
(24, 'Vapriea'),
(25, 'Aovis'),
(26, 'Aenerth'),
(27, 'Pruzozuno'),
(28, 'Shoahiri'),
(29, 'Glomia 02A'),
(30, 'Plade BIL'),
(31, 'Dopraopra'),
(32, 'Tabreyhiri'),
(33, 'Kathiuq'),
(34, 'Zocrade'),
(35, 'Goeria'),
(36, 'Iahines'),
(37, 'Gredotov'),
(38, 'Grafonides'),
(39, 'Whiea A07'),
(40, 'Blinda 65D'),
(41, 'Mostreotania'),
(42, 'Xoswaolea'),
(43, 'Qeshapus'),
(44, 'Askoria'),
(45, 'Foynus'),
(46, 'Aitune'),
(47, 'Fluwoliv'),
(48, 'Blozaturn'),
(49, 'Bleshan WIB'),
(50, 'Glore C279'),
(51, 'Iabreynus'),
(52, 'Dewheutera'),
(53, 'Jaglapus'),
(54, 'Powhadus'),
(55, 'Aynov'),
(56, 'Negawa'),
(57, 'Scolacarro'),
(58, 'Slaeruta'),
(59, 'Crarvis 4'),
(60, 'Freon DJJL'),
(61, 'Kaploihiri'),
(62, 'Utroalea'),
(63, 'Kogleon'),
(64, 'Xacriea'),
(65, 'Vophus'),
(66, 'Suyrilia'),
(67, 'Whekaliv'),
(68, 'Frufawei'),
(69, 'Smiuq 9T7M'),
(70, 'Snao 69C'),
(71, 'Xusmiuruta'),
(72, 'Gufroythea'),
(73, 'Ruthore'),
(74, 'Esnade'),
(75, 'Seylia'),
(76, 'Teulara'),
(77, 'Glagutania'),
(78, 'Thunuter'),
(79, 'Grarth JK'),
(80, 'Ploria XIGM'),
(81, 'Yasmuihines'),
(82, 'Ugliotune'),
(83, 'Peshippe'),
(84, 'Rospion'),
(85, 'Ailiv'),
(86, 'Duotera'),
(87, 'Strouter'),
(88, 'Strasobos'),
(89, 'Shars 75Y'),
(90, 'Strade TD'),
(91, 'Uchuegantu'),
(92, 'Obrewei'),
(93, 'Askeron'),
(94, 'Ducrosie'),
(95, 'Liylea'),
(96, 'Rouclite'),
(97, 'Braputhea'),
(98, 'Straconus'),
(99, 'Blichi WMOE'),
(100, 'Wheshan OEP');

-- --------------------------------------------------------

--
-- Table structure for table `ship`
--

CREATE TABLE `ship` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(128) DEFAULT NULL,
  `cargo_capacity` int(11) DEFAULT NULL,
  `fuel_capacity` int(11) DEFAULT NULL,
  `credits` int(11) DEFAULT NULL,
  `location_x` int(11) DEFAULT NULL,
  `location_y` int(11) DEFAULT NULL,
  `current_fuel` int(11) DEFAULT NULL,
  `turn` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ship`
--

INSERT INTO `ship` (`id`, `name`, `cargo_capacity`, `fuel_capacity`, `credits`, `location_x`, `location_y`, `current_fuel`, `turn`) VALUES
(13, 'New', 100, 100, 99750, 3, 4, 70, 2),
(14, 'Please!!', 100, 100, 99750, 10, 4, 0, 2),
(15, 'Work', 100, 100, 90587, 4, 6, 0, 39),
(16, 'test', 100, 100, 99500, 4, 5, 30, 3),
(17, 'Test', 100, 100, 100000, 3, 3, 80, 1),
(18, 'TestTest', 100, 100, 99528, 3, 5, 60, 2),
(19, 'Testing', 100, 100, 81680, 6, 3, 0, 5),
(20, 'beowulf', 100, 100, 36825, 3, 3, 0, 4),
(21, 'test', 100, 100, 49000, 5, 10, 0, 2),
(22, 'test', 100, 100, 155810, 4, 4, 0, 38);

-- --------------------------------------------------------

--
-- Table structure for table `tradegoods`
--

CREATE TABLE `tradegoods` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(128) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `buy_at` int(11) DEFAULT NULL,
  `sell_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tradegoods`
--

INSERT INTO `tradegoods` (`id`, `name`, `price`, `buy_at`, `sell_at`) VALUES
(1, 'Ore', 90, 1, 2),
(2, 'Grain', 80, 1, 2),
(3, 'Livestock', 110, 1, 2),
(4, 'Consumables', 120, 1, 2),
(5, 'Consumer Goods', 80, 2, 1),
(6, 'Heavy Machinery', 130, 2, 1),
(7, 'Military Hardware', 120, 2, 1),
(8, 'Robots', 100, 2, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cargo`
--
ALTER TABLE `cargo`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `high_scores`
--
ALTER TABLE `high_scores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `parameters`
--
ALTER TABLE `parameters`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `planets`
--
ALTER TABLE `planets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `planet_names`
--
ALTER TABLE `planet_names`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `ship`
--
ALTER TABLE `ship`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `tradegoods`
--
ALTER TABLE `tradegoods`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cargo`
--
ALTER TABLE `cargo`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=185;
--
-- AUTO_INCREMENT for table `high_scores`
--
ALTER TABLE `high_scores`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4161;
--
-- AUTO_INCREMENT for table `parameters`
--
ALTER TABLE `parameters`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;
--
-- AUTO_INCREMENT for table `planets`
--
ALTER TABLE `planets`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2301;
--
-- AUTO_INCREMENT for table `planet_names`
--
ALTER TABLE `planet_names`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;
--
-- AUTO_INCREMENT for table `ship`
--
ALTER TABLE `ship`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `tradegoods`
--
ALTER TABLE `tradegoods`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
