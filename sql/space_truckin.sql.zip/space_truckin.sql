--
-- Database: `space_truckin`
--
CREATE DATABASE IF NOT EXISTS `space_truckin` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `space_truckin`;

-- --------------------------------------------------------

--
-- Table structure for table `cargo`
--

CREATE TABLE `cargo` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `id_tradegoods` int(11) DEFAULT NULL,
  `id_ship` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `id_planets` int(11) DEFAULT NULL,
  `id_tradegoods` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `parameters`
--

CREATE TABLE `parameters` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(128) DEFAULT NULL,
  `value` int(11) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `parameters`
--

INSERT INTO `parameters` (`id`, `name`, `value`, `type`) VALUES
(1, 'pop_1_max_inventory', 30, 'max_inventory'),
(2, 'pop_2_max_inventory', 75, 'max_inventory'),
(3, 'pop_3_max_inventory', 100, 'max_inventory'),
(4, 'type_match_min_factor', 25, 'type_factor'),
(5, 'type_match_max_factor', 50, 'type_factor'),
(6, 'type_mismatch_min_factor', 150, 'type_factor'),
(7, 'type_mismatch_max_factor', 200, 'type_factor'),
(8, 'pop_1_min_factor', 50, 'pop_factor'),
(9, 'pop_1_max_factor', 75, 'pop_factor'),
(10, 'pop_2_min_factor', 100, 'pop_factor'),
(11, 'pop_2_max_factor', 100, 'pop_factor'),
(12, 'pop_3_min_factor', 150, 'pop_factor'),
(13, 'pop_3_max_factor', 200, 'pop_factor'),
(14, 'specialty_min_factor', 25, 'specialty_factor'),
(15, 'specialty_max_factor', 50, 'specialty_factor'),
(16, 'controlled_min_factor', 150, 'controlled_factor'),
(17, 'controlled_max_factor', 200, 'controlled_factor'),
(18, 'min_planet_density', 28, 'system_setup'),
(19, 'max_planet_density', 35, 'system_setup'),
(20, 'universe_size_sqrt', 10, 'system_setup'),
(21, 'ag_planet_share', 35, 'system_setup'),
(22, 'in_planet_share', 35, 'system_setup'),
(23, 'fuel_planet_share', 30, 'system_setup');

-- --------------------------------------------------------

--
-- Table structure for table `planets`
--

CREATE TABLE `planets` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `type` int(11) DEFAULT NULL,
  `population` int(11) DEFAULT NULL,
  `location_x` int(11) DEFAULT NULL,
  `location_y` int(11) DEFAULT NULL,
  `specialty` int(11) DEFAULT NULL,
  `controlled` int(11) DEFAULT NULL,
  `regular` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ship`
--

CREATE TABLE `ship` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(128) DEFAULT NULL,
  `cargo_capacity` int(11) DEFAULT NULL,
  `fuel_capacity` int(11) DEFAULT NULL,
  `credits` int(11) DEFAULT NULL,
  `location_x` int(11) DEFAULT NULL,
  `location_y` int(11) DEFAULT NULL,
  `current_fuel` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tradegoods`
--

CREATE TABLE `tradegoods` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(128) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `buy_at` int(11) DEFAULT NULL,
  `sell_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tradegoods`
--

INSERT INTO `tradegoods` (`id`, `name`, `price`, `buy_at`, `sell_at`) VALUES
(1, 'Ore', 10, 1, 2),
(2, 'Grain', 10, 1, 2),
(3, 'Livestock', 10, 1, 2),
(4, 'Consumables', 10, 1, 2),
(5, 'Consumer Goods', 10, 2, 1),
(6, 'Heavy Machinery', 10, 2, 1),
(7, 'Military Hardware', 10, 2, 1),
(8, 'Robots', 10, 2, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cargo`
--
ALTER TABLE `cargo`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `parameters`
--
ALTER TABLE `parameters`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `planets`
--
ALTER TABLE `planets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `ship`
--
ALTER TABLE `ship`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `tradegoods`
--
ALTER TABLE `tradegoods`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cargo`
--
ALTER TABLE `cargo`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `parameters`
--
ALTER TABLE `parameters`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `planets`
--
ALTER TABLE `planets`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ship`
--
ALTER TABLE `ship`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tradegoods`
--
ALTER TABLE `tradegoods`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
