--
-- Database: `space_truckin`
--
CREATE DATABASE IF NOT EXISTS `space_truckin` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `space_truckin`;

-- --------------------------------------------------------

--
-- Table structure for table `cargo`
--

CREATE TABLE `cargo` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `id_tradegoods` int(11) DEFAULT NULL,
  `id_ship` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `id_planets` int(11) DEFAULT NULL,
  `id_tradegoods` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `parameters`
--

CREATE TABLE `parameters` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(128) DEFAULT NULL,
  `value` int(11) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `parameters`
--

INSERT INTO `parameters` (`id`, `name`, `value`, `type`) VALUES
(1, 'pop_1_max_inventory', 30, 'max_inventory'),
(2, 'pop_2_max_inventory', 75, 'max_inventory'),
(3, 'pop_3_max_inventory', 100, 'max_inventory'),
(4, 'type_match_min_factor', 25, 'type_factor'),
(5, 'type_match_max_factor', 50, 'type_factor'),
(6, 'type_mismatch_min_factor', 150, 'type_factor'),
(7, 'type_mismatch_max_factor', 200, 'type_factor'),
(8, 'pop_1_min_factor', 50, 'pop_factor'),
(9, 'pop_1_max_factor', 75, 'pop_factor'),
(10, 'pop_2_min_factor', 100, 'pop_factor'),
(11, 'pop_2_max_factor', 100, 'pop_factor'),
(12, 'pop_3_min_factor', 150, 'pop_factor'),
(13, 'pop_3_max_factor', 200, 'pop_factor'),
(14, 'specialty_min_factor', 25, 'specialty_factor'),
(15, 'specialty_max_factor', 50, 'specialty_factor'),
(16, 'controlled_min_factor', 150, 'controlled_factor'),
(17, 'controlled_max_factor', 200, 'controlled_factor'),
(18, 'min_planet_density', 28, 'system_setup'),
(19, 'max_planet_density', 35, 'system_setup'),
(20, 'universe_size_sqrt', 10, 'system_setup'),
(21, 'ag_planet_share', 35, 'system_setup'),
(22, 'in_planet_share', 35, 'system_setup'),
(23, 'fuel_planet_share', 30, 'system_setup'),
(24, 'inventory_increment_min_percent', 10, 'increment_percent'),
(25, 'inventory_increment_max_percent', 25, 'increment_percent'),
(26, 'increment_specialty_share', 67, 'increment_percent'),
(27, 'increment_regular_share', 33, 'increment_percent'),
(28, 'fuel_price', 10, 'gameplay'),
(29, 'max_fuel', 100, 'gameplay'),
(30, 'starting_fuel', 80, 'gameplay'),
(31, 'max_cargo', 100, 'gameplay'),
(32, 'starting_credits', 500, 'gameplay'),
(33, 'starting_x', 3, 'gameplay'),
(34, 'starting_y', 3, 'gameplay');

-- --------------------------------------------------------

--
-- Table structure for table `planets`
--

CREATE TABLE `planets` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `type` int(11) DEFAULT NULL,
  `population` int(11) DEFAULT NULL,
  `location_x` int(11) DEFAULT NULL,
  `location_y` int(11) DEFAULT NULL,
  `specialty` int(11) DEFAULT NULL,
  `controlled` int(11) DEFAULT NULL,
  `regular` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `planet_names`
--

CREATE TABLE `planet_names` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `planet_names`
--

INSERT INTO `planet_names` (`id`, `name`) VALUES
(1, 'Odriulia'),
(2, 'Echoyhines'),
(3, 'Vobrarth'),
(4, 'Eslion'),
(5, 'Peyter'),
(6, 'Yiylia'),
(7, 'Gretothea'),
(8, 'Slamanus'),
(9, 'Treron NQ5'),
(10, 'Trore HU'),
(11, 'Tusneinus'),
(12, 'Deproilara'),
(13, 'Maswov'),
(14, 'Gacrorth'),
(15, 'Mopra'),
(16, 'Xuagantu'),
(17, 'Brusoclite'),
(18, 'Snegunides'),
(19, 'Shurn 3G17'),
(20, 'Scilia 48'),
(21, 'Cestreter'),
(22, 'Fawhauter'),
(23, 'Hosnora'),
(24, 'Vapriea'),
(25, 'Aovis'),
(26, 'Aenerth'),
(27, 'Pruzozuno'),
(28, 'Shoahiri'),
(29, 'Glomia 02A'),
(30, 'Plade BIL'),
(31, 'Dopraopra'),
(32, 'Tabreyhiri'),
(33, 'Kathiuq'),
(34, 'Zocrade'),
(35, 'Goeria'),
(36, 'Iahines'),
(37, 'Gredotov'),
(38, 'Grafonides'),
(39, 'Whiea A07'),
(40, 'Blinda 65D'),
(41, 'Mostreotania'),
(42, 'Xoswaolea'),
(43, 'Qeshapus'),
(44, 'Askoria'),
(45, 'Foynus'),
(46, 'Aitune'),
(47, 'Fluwoliv'),
(48, 'Blozaturn'),
(49, 'Bleshan WIB'),
(50, 'Glore C279'),
(51, 'Iabreynus'),
(52, 'Dewheutera'),
(53, 'Jaglapus'),
(54, 'Powhadus'),
(55, 'Aynov'),
(56, 'Negawa'),
(57, 'Scolacarro'),
(58, 'Slaeruta'),
(59, 'Crarvis 4'),
(60, 'Freon DJJL'),
(61, 'Kaploihiri'),
(62, 'Utroalea'),
(63, 'Kogleon'),
(64, 'Xacriea'),
(65, 'Vophus'),
(66, 'Suyrilia'),
(67, 'Whekaliv'),
(68, 'Frufawei'),
(69, 'Smiuq 9T7M'),
(70, 'Snao 69C'),
(71, 'Xusmiuruta'),
(72, 'Gufroythea'),
(73, 'Ruthore'),
(74, 'Esnade'),
(75, 'Seylia'),
(76, 'Teulara'),
(77, 'Glagutania'),
(78, 'Thunuter'),
(79, 'Grarth JK'),
(80, 'Ploria XIGM'),
(81, 'Yasmuihines'),
(82, 'Ugliotune'),
(83, 'Peshippe'),
(84, 'Rospion'),
(85, 'Ailiv'),
(86, 'Duotera'),
(87, 'Strouter'),
(88, 'Strasobos'),
(89, 'Shars 75Y'),
(90, 'Strade TD'),
(91, 'Uchuegantu'),
(92, 'Obrewei'),
(93, 'Askeron'),
(94, 'Ducrosie'),
(95, 'Liylea'),
(96, 'Rouclite'),
(97, 'Braputhea'),
(98, 'Straconus'),
(99, 'Blichi WMOE'),
(100, 'Wheshan OEP');

-- --------------------------------------------------------

--
-- Table structure for table `ship`
--

CREATE TABLE `ship` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(128) DEFAULT NULL,
  `cargo_capacity` int(11) DEFAULT NULL,
  `fuel_capacity` int(11) DEFAULT NULL,
  `credits` int(11) DEFAULT NULL,
  `location_x` int(11) DEFAULT NULL,
  `location_y` int(11) DEFAULT NULL,
  `current_fuel` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tradegoods`
--

CREATE TABLE `tradegoods` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(128) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `buy_at` int(11) DEFAULT NULL,
  `sell_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tradegoods`
--

INSERT INTO `tradegoods` (`id`, `name`, `price`, `buy_at`, `sell_at`) VALUES
(1, 'Ore', 10, 1, 2),
(2, 'Grain', 10, 1, 2),
(3, 'Livestock', 10, 1, 2),
(4, 'Consumables', 10, 1, 2),
(5, 'Consumer Goods', 10, 2, 1),
(6, 'Heavy Machinery', 10, 2, 1),
(7, 'Military Hardware', 10, 2, 1),
(8, 'Robots', 10, 2, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cargo`
--
ALTER TABLE `cargo`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `parameters`
--
ALTER TABLE `parameters`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `planets`
--
ALTER TABLE `planets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `planet_names`
--
ALTER TABLE `planet_names`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `ship`
--
ALTER TABLE `ship`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `tradegoods`
--
ALTER TABLE `tradegoods`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cargo`
--
ALTER TABLE `cargo`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=105;
--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2929;
--
-- AUTO_INCREMENT for table `parameters`
--
ALTER TABLE `parameters`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
--
-- AUTO_INCREMENT for table `planets`
--
ALTER TABLE `planets`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1601;
--
-- AUTO_INCREMENT for table `planet_names`
--
ALTER TABLE `planet_names`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;
--
-- AUTO_INCREMENT for table `ship`
--
ALTER TABLE `ship`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `tradegoods`
--
ALTER TABLE `tradegoods`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
