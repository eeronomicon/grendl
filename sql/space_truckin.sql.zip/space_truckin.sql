--
-- Database: `space_truckin`
--
CREATE DATABASE IF NOT EXISTS `space_truckin` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `space_truckin`;

-- --------------------------------------------------------

--
-- Table structure for table `cargo`
--

CREATE TABLE `cargo` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `id_tradegoods` int(11) DEFAULT NULL,
  `id_ship` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cargo`
--

INSERT INTO `cargo` (`id`, `id_tradegoods`, `id_ship`, `quantity`) VALUES
(105, 1, 13, 0),
(106, 2, 13, 0),
(107, 3, 13, 0),
(108, 4, 13, 0),
(109, 5, 13, 0),
(110, 6, 13, 0),
(111, 7, 13, 0),
(112, 8, 13, 0),
(113, 1, 14, 0),
(114, 2, 14, 0),
(115, 3, 14, 0),
(116, 4, 14, 0),
(117, 5, 14, 0),
(118, 6, 14, 0),
(119, 7, 14, 0),
(120, 8, 14, 0),
(121, 1, 15, 0),
(122, 2, 15, 0),
(123, 3, 15, 0),
(124, 4, 15, 0),
(125, 5, 15, 0),
(126, 6, 15, 0),
(127, 7, 15, 0),
(128, 8, 15, 0);

-- --------------------------------------------------------

--
-- Table structure for table `high_scores`
--

CREATE TABLE `high_scores` (
  `ship_name` varchar(255) DEFAULT NULL,
  `score` int(11) DEFAULT NULL,
  `id` bigint(20) UNSIGNED NOT NULL,
  `turn` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `high_scores`
--

INSERT INTO `high_scores` (`ship_name`, `score`, `id`, `turn`) VALUES
('Beowulf', 452, 1, 45),
('Serenity', 768, 2, 45),
('Apollo 11', -45, 3, 45),
('Ship Seven', 94000, 4, 45),
('Back to space', 99500, 5, 3),
('Please!!', 99750, 8, 2);

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `id_planets` int(11) DEFAULT NULL,
  `id_tradegoods` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`id`, `id_planets`, `id_tradegoods`, `quantity`, `price`) VALUES
(2753, 7, 1, 0, 16),
(2754, 7, 2, 0, 20),
(2755, 7, 3, 0, 19),
(2756, 7, 4, 0, 30),
(2757, 7, 5, 47, 4),
(2758, 7, 6, 0, 16),
(2759, 7, 7, 32, 17),
(2760, 7, 8, 0, 19),
(2761, 9, 1, 0, 2),
(2762, 9, 2, 0, 2),
(2763, 9, 3, 25, 1),
(2764, 9, 4, 8, 2),
(2765, 9, 5, 0, 24),
(2766, 9, 6, 0, 9),
(2767, 9, 7, 0, 8),
(2768, 9, 8, 0, 11),
(2769, 10, 1, 0, 3),
(2770, 10, 2, 18, 0),
(2771, 10, 3, 0, 2),
(2772, 10, 4, 14, 2),
(2773, 10, 5, 0, 13),
(2774, 10, 6, 0, 12),
(2775, 10, 7, 0, 12),
(2776, 10, 8, 0, 18),
(2777, 23, 1, 0, 27),
(2778, 23, 2, 0, 64),
(2779, 23, 3, 0, 33),
(2780, 23, 4, 50, 37),
(2781, 23, 5, 0, 35),
(2782, 23, 6, 0, 26),
(2783, 23, 7, 57, 11),
(2784, 23, 8, 0, 34),
(2785, 24, 1, 63, 1),
(2786, 24, 2, 0, 7),
(2787, 24, 3, 0, 5),
(2788, 24, 4, 0, 4),
(2789, 24, 5, 52, 32),
(2790, 24, 6, 0, 31),
(2791, 24, 7, 0, 58),
(2792, 24, 8, 0, 31),
(2793, 32, 1, 0, 3),
(2794, 32, 2, 19, 1),
(2795, 32, 3, 0, 2),
(2796, 32, 4, 0, 2),
(2797, 32, 5, 0, 11),
(2798, 32, 6, 0, 18),
(2799, 32, 7, 0, 12),
(2800, 32, 8, 14, 12),
(2801, 35, 1, 44, 30),
(2802, 35, 2, 0, 38),
(2803, 35, 3, 0, 46),
(2804, 35, 4, 0, 26),
(2805, 35, 5, 58, 13),
(2806, 35, 6, 0, 25),
(2807, 35, 7, 0, 30),
(2808, 35, 8, 0, 28),
(2809, 36, 1, 0, 29),
(2810, 36, 2, 0, 19),
(2811, 36, 3, 0, 20),
(2812, 36, 4, 33, 17),
(2813, 36, 5, 49, 8),
(2814, 36, 6, 0, 17),
(2815, 36, 7, 0, 16),
(2816, 36, 8, 0, 18),
(2817, 41, 1, 0, 17),
(2818, 41, 2, 0, 18),
(2819, 41, 3, 0, 24),
(2820, 41, 4, 0, 15),
(2821, 41, 5, 0, 20),
(2822, 41, 6, 40, 6),
(2823, 41, 7, 0, 19),
(2824, 41, 8, 35, 16),
(2825, 43, 1, 0, 3),
(2826, 43, 2, 54, 1),
(2827, 43, 3, 0, 3),
(2828, 43, 4, 0, 3),
(2829, 43, 5, 0, 18),
(2830, 43, 6, 28, 17),
(2831, 43, 7, 0, 19),
(2832, 43, 8, 0, 34),
(2833, 47, 1, 0, 61),
(2834, 47, 2, 0, 26),
(2835, 47, 3, 0, 30),
(2836, 47, 4, 0, 35),
(2837, 47, 5, 0, 35),
(2838, 47, 6, 42, 30),
(2839, 47, 7, 63, 8),
(2840, 47, 8, 0, 33),
(2841, 49, 1, 22, 16),
(2842, 49, 2, 0, 35),
(2843, 49, 3, 0, 16),
(2844, 49, 4, 0, 17),
(2845, 49, 5, 0, 16),
(2846, 49, 6, 63, 6),
(2847, 49, 7, 0, 19),
(2848, 49, 8, 0, 18),
(2849, 53, 1, 0, 5),
(2850, 53, 2, 0, 9),
(2851, 53, 3, 0, 9),
(2852, 53, 4, 57, 2),
(2853, 53, 5, 0, 28),
(2854, 53, 6, 0, 30),
(2855, 53, 7, 47, 31),
(2856, 53, 8, 0, 42),
(2857, 60, 1, 0, 16),
(2858, 60, 2, 0, 20),
(2859, 60, 3, 0, 34),
(2860, 60, 4, 34, 19),
(2861, 60, 5, 51, 4),
(2862, 60, 6, 0, 17),
(2863, 60, 7, 0, 17),
(2864, 60, 8, 0, 20),
(2865, 62, 1, 0, 17),
(2866, 62, 2, 11, 9),
(2867, 62, 3, 0, 9),
(2868, 62, 4, 0, 11),
(2869, 62, 5, 0, 12),
(2870, 62, 6, 0, 12),
(2871, 62, 7, 0, 10),
(2872, 62, 8, 21, 3),
(2873, 66, 1, 83, 3),
(2874, 66, 2, 0, 9),
(2875, 66, 3, 0, 7),
(2876, 66, 4, 28, 6),
(2877, 66, 5, 0, 30),
(2878, 66, 6, 0, 30),
(2879, 66, 7, 0, 43),
(2880, 66, 8, 0, 28),
(2881, 74, 1, 0, 27),
(2882, 74, 2, 0, 32),
(2883, 74, 3, 0, 60),
(2884, 74, 4, 0, 26),
(2885, 74, 5, 44, 33),
(2886, 74, 6, 57, 15),
(2887, 74, 7, 0, 34),
(2888, 74, 8, 0, 34),
(2889, 75, 1, 0, 2),
(2890, 75, 2, 10, 2),
(2891, 75, 3, 0, 3),
(2892, 75, 4, 20, 1),
(2893, 75, 5, 0, 11),
(2894, 75, 6, 0, 10),
(2895, 75, 7, 0, 19),
(2896, 75, 8, 0, 11),
(2897, 77, 1, 0, 5),
(2898, 77, 2, 53, 2),
(2899, 77, 3, 0, 3),
(2900, 77, 4, 0, 3),
(2901, 77, 5, 28, 17),
(2902, 77, 6, 0, 20),
(2903, 77, 7, 0, 40),
(2904, 77, 8, 0, 18),
(2905, 80, 1, 0, 19),
(2906, 80, 2, 0, 20),
(2907, 80, 3, 33, 16),
(2908, 80, 4, 0, 25),
(2909, 80, 5, 0, 16),
(2910, 80, 6, 50, 6),
(2911, 80, 7, 0, 17),
(2912, 80, 8, 0, 18),
(2913, 85, 1, 0, 16),
(2914, 85, 2, 0, 10),
(2915, 85, 3, 0, 8),
(2916, 85, 4, 0, 8),
(2917, 85, 5, 18, 4),
(2918, 85, 6, 0, 9),
(2919, 85, 7, 14, 11),
(2920, 85, 8, 0, 13),
(2921, 86, 1, 0, 3),
(2922, 86, 2, 0, 3),
(2923, 86, 3, 0, 5),
(2924, 86, 4, 52, 2),
(2925, 86, 5, 26, 16),
(2926, 86, 6, 0, 19),
(2927, 86, 7, 0, 16),
(2928, 86, 8, 0, 27),
(2929, 87, 1, 52, 1),
(2930, 87, 2, 27, 4),
(2931, 87, 3, 0, 5),
(2932, 87, 4, 0, 4),
(2933, 87, 5, 0, 33),
(2934, 87, 6, 0, 17),
(2935, 87, 7, 0, 16),
(2936, 87, 8, 0, 18),
(2937, 90, 1, 17, 1),
(2938, 90, 2, 0, 3),
(2939, 90, 3, 0, 2),
(2940, 90, 4, 16, 3),
(2941, 90, 5, 0, 19),
(2942, 90, 6, 0, 13),
(2943, 90, 7, 0, 10),
(2944, 90, 8, 0, 11);

-- --------------------------------------------------------

--
-- Table structure for table `parameters`
--

CREATE TABLE `parameters` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(128) DEFAULT NULL,
  `value` int(11) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `parameters`
--

INSERT INTO `parameters` (`id`, `name`, `value`, `type`) VALUES
(1, 'pop_1_max_inventory', 30, 'max_inventory'),
(2, 'pop_2_max_inventory', 75, 'max_inventory'),
(3, 'pop_3_max_inventory', 100, 'max_inventory'),
(4, 'type_match_min_factor', 25, 'type_factor'),
(5, 'type_match_max_factor', 50, 'type_factor'),
(6, 'type_mismatch_min_factor', 150, 'type_factor'),
(7, 'type_mismatch_max_factor', 200, 'type_factor'),
(8, 'pop_1_min_factor', 50, 'pop_factor'),
(9, 'pop_1_max_factor', 75, 'pop_factor'),
(10, 'pop_2_min_factor', 100, 'pop_factor'),
(11, 'pop_2_max_factor', 100, 'pop_factor'),
(12, 'pop_3_min_factor', 150, 'pop_factor'),
(13, 'pop_3_max_factor', 200, 'pop_factor'),
(14, 'specialty_min_factor', 25, 'specialty_factor'),
(15, 'specialty_max_factor', 50, 'specialty_factor'),
(16, 'controlled_min_factor', 150, 'controlled_factor'),
(17, 'controlled_max_factor', 200, 'controlled_factor'),
(18, 'min_planet_density', 28, 'system_setup'),
(19, 'max_planet_density', 35, 'system_setup'),
(20, 'universe_size_sqrt', 10, 'system_setup'),
(21, 'ag_planet_share', 35, 'system_setup'),
(22, 'in_planet_share', 35, 'system_setup'),
(23, 'fuel_planet_share', 30, 'system_setup'),
(24, 'inventory_increment_min_percent', 10, 'increment_percent'),
(25, 'inventory_increment_max_percent', 25, 'increment_percent'),
(26, 'increment_specialty_share', 67, 'increment_percent'),
(27, 'increment_regular_share', 33, 'increment_percent'),
(28, 'fuel_price', 10, 'gameplay'),
(29, 'max_fuel', 100, 'gameplay'),
(30, 'starting_fuel', 80, 'gameplay'),
(31, 'max_cargo', 100, 'gameplay'),
(32, 'starting_credits', 100000, 'gameplay'),
(33, 'starting_x', 3, 'gameplay'),
(34, 'starting_y', 3, 'gameplay'),
(35, 'max_turns', 50, 'gameplay'),
(36, 'upkeep_cost', 250, 'gameplay'),
(37, 'travel_cost', 10, 'gameplay');

-- --------------------------------------------------------

--
-- Table structure for table `planets`
--

CREATE TABLE `planets` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `type` int(11) DEFAULT NULL,
  `population` int(11) DEFAULT NULL,
  `location_x` int(11) DEFAULT NULL,
  `location_y` int(11) DEFAULT NULL,
  `specialty` int(11) DEFAULT NULL,
  `controlled` int(11) DEFAULT NULL,
  `regular` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `planets`
--

INSERT INTO `planets` (`id`, `type`, `population`, `location_x`, `location_y`, `specialty`, `controlled`, `regular`, `name`) VALUES
(1, 0, 0, 1, 1, 0, 0, 0, ''),
(2, 0, 0, 1, 2, 0, 0, 0, ''),
(3, 0, 0, 1, 3, 0, 0, 0, ''),
(4, 0, 0, 1, 4, 0, 0, 0, ''),
(5, 0, 0, 1, 5, 0, 0, 0, ''),
(6, 0, 0, 1, 6, 0, 0, 0, ''),
(7, 2, 2, 1, 7, 5, 4, 7, 'Hosnora'),
(8, 0, 0, 1, 8, 0, 0, 0, ''),
(9, 1, 1, 1, 9, 3, 5, 4, 'Whiea A07'),
(10, 1, 1, 1, 10, 2, 8, 4, 'Xusmiuruta'),
(11, 3, 0, 2, 1, 0, 0, 0, 'Xoswaolea'),
(12, 0, 0, 2, 2, 0, 0, 0, ''),
(13, 3, 0, 2, 3, 0, 0, 0, 'Whekaliv'),
(14, 0, 0, 2, 4, 0, 0, 0, ''),
(15, 0, 0, 2, 5, 0, 0, 0, ''),
(16, 0, 0, 2, 6, 0, 0, 0, ''),
(17, 0, 0, 2, 7, 0, 0, 0, ''),
(18, 0, 0, 2, 8, 0, 0, 0, ''),
(19, 0, 0, 2, 9, 0, 0, 0, ''),
(20, 0, 0, 2, 10, 0, 0, 0, ''),
(21, 3, 0, 3, 1, 0, 0, 0, 'Mostreotania'),
(22, 0, 0, 3, 2, 0, 0, 0, ''),
(23, 2, 3, 3, 3, 7, 2, 4, 'Ducrosie'),
(24, 1, 3, 3, 4, 1, 7, 5, 'Uchuegantu'),
(25, 0, 0, 3, 5, 0, 0, 0, ''),
(26, 0, 0, 3, 6, 0, 0, 0, ''),
(27, 0, 0, 3, 7, 0, 0, 0, ''),
(28, 0, 0, 3, 8, 0, 0, 0, ''),
(29, 0, 0, 3, 9, 0, 0, 0, ''),
(30, 0, 0, 3, 10, 0, 0, 0, ''),
(31, 0, 0, 4, 1, 0, 0, 0, ''),
(32, 1, 1, 4, 2, 2, 6, 8, 'Mostreotania'),
(33, 0, 0, 4, 3, 0, 0, 0, ''),
(34, 0, 0, 4, 4, 0, 0, 0, ''),
(35, 2, 3, 4, 5, 5, 3, 1, 'Askoria'),
(36, 2, 2, 4, 6, 5, 1, 4, 'Shurn 3G17'),
(37, 0, 0, 4, 7, 0, 0, 0, ''),
(38, 0, 0, 4, 8, 0, 0, 0, ''),
(39, 0, 0, 4, 9, 0, 0, 0, ''),
(40, 0, 0, 4, 10, 0, 0, 0, ''),
(41, 2, 2, 5, 1, 6, 3, 8, 'Glomia 02A'),
(42, 0, 0, 5, 2, 0, 0, 0, ''),
(43, 1, 2, 5, 3, 2, 8, 6, 'Strade TD'),
(44, 0, 0, 5, 4, 0, 0, 0, ''),
(45, 0, 0, 5, 5, 0, 0, 0, ''),
(46, 0, 0, 5, 6, 0, 0, 0, ''),
(47, 2, 3, 5, 7, 7, 1, 6, 'Plade BIL'),
(48, 0, 0, 5, 8, 0, 0, 0, ''),
(49, 2, 2, 5, 9, 6, 2, 1, 'Hosnora'),
(50, 0, 0, 5, 10, 0, 0, 0, ''),
(51, 3, 0, 6, 1, 0, 0, 0, 'Fawhauter'),
(52, 0, 0, 6, 2, 0, 0, 0, ''),
(53, 1, 3, 6, 3, 4, 8, 7, 'Treron NQ5'),
(54, 0, 0, 6, 4, 0, 0, 0, ''),
(55, 0, 0, 6, 5, 0, 0, 0, ''),
(56, 0, 0, 6, 6, 0, 0, 0, ''),
(57, 0, 0, 6, 7, 0, 0, 0, ''),
(58, 0, 0, 6, 8, 0, 0, 0, ''),
(59, 0, 0, 6, 9, 0, 0, 0, ''),
(60, 2, 2, 6, 10, 5, 3, 4, 'Xusmiuruta'),
(61, 0, 0, 7, 1, 0, 0, 0, ''),
(62, 2, 1, 7, 2, 8, 1, 2, 'Tabreyhiri'),
(63, 0, 0, 7, 3, 0, 0, 0, ''),
(64, 3, 0, 7, 4, 0, 0, 0, 'Strouter'),
(65, 0, 0, 7, 5, 0, 0, 0, ''),
(66, 1, 3, 7, 6, 1, 7, 4, 'Ploria XIGM'),
(67, 0, 0, 7, 7, 0, 0, 0, ''),
(68, 0, 0, 7, 8, 0, 0, 0, ''),
(69, 3, 0, 7, 9, 0, 0, 0, 'Yasmuihines'),
(70, 0, 0, 7, 10, 0, 0, 0, ''),
(71, 0, 0, 8, 1, 0, 0, 0, ''),
(72, 0, 0, 8, 2, 0, 0, 0, ''),
(73, 0, 0, 8, 3, 0, 0, 0, ''),
(74, 2, 3, 8, 4, 6, 3, 5, 'Zocrade'),
(75, 1, 1, 8, 5, 4, 7, 2, 'Thunuter'),
(76, 3, 0, 8, 6, 0, 0, 0, 'Dopraopra'),
(77, 1, 2, 8, 7, 2, 7, 5, 'Scilia 48'),
(78, 0, 0, 8, 8, 0, 0, 0, ''),
(79, 0, 0, 8, 9, 0, 0, 0, ''),
(80, 2, 2, 8, 10, 6, 4, 3, 'Grafonides'),
(81, 0, 0, 9, 1, 0, 0, 0, ''),
(82, 0, 0, 9, 2, 0, 0, 0, ''),
(83, 0, 0, 9, 3, 0, 0, 0, ''),
(84, 0, 0, 9, 4, 0, 0, 0, ''),
(85, 2, 1, 9, 5, 5, 1, 7, 'Strouter'),
(86, 1, 2, 9, 6, 4, 8, 5, 'Goeria'),
(87, 1, 2, 9, 7, 1, 5, 2, 'Rospion'),
(88, 0, 0, 9, 8, 0, 0, 0, ''),
(89, 3, 0, 9, 9, 0, 0, 0, 'Strasobos'),
(90, 1, 1, 9, 10, 1, 5, 4, 'Qeshapus'),
(91, 0, 0, 10, 1, 0, 0, 0, ''),
(92, 0, 0, 10, 2, 0, 0, 0, ''),
(93, 0, 0, 10, 3, 0, 0, 0, ''),
(94, 0, 0, 10, 4, 0, 0, 0, ''),
(95, 0, 0, 10, 5, 0, 0, 0, ''),
(96, 0, 0, 10, 6, 0, 0, 0, ''),
(97, 0, 0, 10, 7, 0, 0, 0, ''),
(98, 3, 0, 10, 8, 0, 0, 0, 'Scolacarro'),
(99, 3, 0, 10, 9, 0, 0, 0, 'Tusneinus'),
(100, 0, 0, 10, 10, 0, 0, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `planet_names`
--

CREATE TABLE `planet_names` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `planet_names`
--

INSERT INTO `planet_names` (`id`, `name`) VALUES
(1, 'Odriulia'),
(2, 'Echoyhines'),
(3, 'Vobrarth'),
(4, 'Eslion'),
(5, 'Peyter'),
(6, 'Yiylia'),
(7, 'Gretothea'),
(8, 'Slamanus'),
(9, 'Treron NQ5'),
(10, 'Trore HU'),
(11, 'Tusneinus'),
(12, 'Deproilara'),
(13, 'Maswov'),
(14, 'Gacrorth'),
(15, 'Mopra'),
(16, 'Xuagantu'),
(17, 'Brusoclite'),
(18, 'Snegunides'),
(19, 'Shurn 3G17'),
(20, 'Scilia 48'),
(21, 'Cestreter'),
(22, 'Fawhauter'),
(23, 'Hosnora'),
(24, 'Vapriea'),
(25, 'Aovis'),
(26, 'Aenerth'),
(27, 'Pruzozuno'),
(28, 'Shoahiri'),
(29, 'Glomia 02A'),
(30, 'Plade BIL'),
(31, 'Dopraopra'),
(32, 'Tabreyhiri'),
(33, 'Kathiuq'),
(34, 'Zocrade'),
(35, 'Goeria'),
(36, 'Iahines'),
(37, 'Gredotov'),
(38, 'Grafonides'),
(39, 'Whiea A07'),
(40, 'Blinda 65D'),
(41, 'Mostreotania'),
(42, 'Xoswaolea'),
(43, 'Qeshapus'),
(44, 'Askoria'),
(45, 'Foynus'),
(46, 'Aitune'),
(47, 'Fluwoliv'),
(48, 'Blozaturn'),
(49, 'Bleshan WIB'),
(50, 'Glore C279'),
(51, 'Iabreynus'),
(52, 'Dewheutera'),
(53, 'Jaglapus'),
(54, 'Powhadus'),
(55, 'Aynov'),
(56, 'Negawa'),
(57, 'Scolacarro'),
(58, 'Slaeruta'),
(59, 'Crarvis 4'),
(60, 'Freon DJJL'),
(61, 'Kaploihiri'),
(62, 'Utroalea'),
(63, 'Kogleon'),
(64, 'Xacriea'),
(65, 'Vophus'),
(66, 'Suyrilia'),
(67, 'Whekaliv'),
(68, 'Frufawei'),
(69, 'Smiuq 9T7M'),
(70, 'Snao 69C'),
(71, 'Xusmiuruta'),
(72, 'Gufroythea'),
(73, 'Ruthore'),
(74, 'Esnade'),
(75, 'Seylia'),
(76, 'Teulara'),
(77, 'Glagutania'),
(78, 'Thunuter'),
(79, 'Grarth JK'),
(80, 'Ploria XIGM'),
(81, 'Yasmuihines'),
(82, 'Ugliotune'),
(83, 'Peshippe'),
(84, 'Rospion'),
(85, 'Ailiv'),
(86, 'Duotera'),
(87, 'Strouter'),
(88, 'Strasobos'),
(89, 'Shars 75Y'),
(90, 'Strade TD'),
(91, 'Uchuegantu'),
(92, 'Obrewei'),
(93, 'Askeron'),
(94, 'Ducrosie'),
(95, 'Liylea'),
(96, 'Rouclite'),
(97, 'Braputhea'),
(98, 'Straconus'),
(99, 'Blichi WMOE'),
(100, 'Wheshan OEP');

-- --------------------------------------------------------

--
-- Table structure for table `ship`
--

CREATE TABLE `ship` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(128) DEFAULT NULL,
  `cargo_capacity` int(11) DEFAULT NULL,
  `fuel_capacity` int(11) DEFAULT NULL,
  `credits` int(11) DEFAULT NULL,
  `location_x` int(11) DEFAULT NULL,
  `location_y` int(11) DEFAULT NULL,
  `current_fuel` int(11) DEFAULT NULL,
  `turn` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ship`
--

INSERT INTO `ship` (`id`, `name`, `cargo_capacity`, `fuel_capacity`, `credits`, `location_x`, `location_y`, `current_fuel`, `turn`) VALUES
(13, 'New', 100, 100, 99750, 3, 4, 70, 2),
(14, 'Please!!', 100, 100, 99750, 10, 4, 0, 2),
(15, 'Work', 100, 100, 98500, 3, 5, 60, 10);

-- --------------------------------------------------------

--
-- Table structure for table `tradegoods`
--

CREATE TABLE `tradegoods` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(128) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `buy_at` int(11) DEFAULT NULL,
  `sell_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tradegoods`
--

INSERT INTO `tradegoods` (`id`, `name`, `price`, `buy_at`, `sell_at`) VALUES
(1, 'Ore', 10, 1, 2),
(2, 'Grain', 10, 1, 2),
(3, 'Livestock', 10, 1, 2),
(4, 'Consumables', 10, 1, 2),
(5, 'Consumer Goods', 10, 2, 1),
(6, 'Heavy Machinery', 10, 2, 1),
(7, 'Military Hardware', 10, 2, 1),
(8, 'Robots', 10, 2, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cargo`
--
ALTER TABLE `cargo`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `high_scores`
--
ALTER TABLE `high_scores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `parameters`
--
ALTER TABLE `parameters`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `planets`
--
ALTER TABLE `planets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `planet_names`
--
ALTER TABLE `planet_names`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `ship`
--
ALTER TABLE `ship`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `tradegoods`
--
ALTER TABLE `tradegoods`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cargo`
--
ALTER TABLE `cargo`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=129;
--
-- AUTO_INCREMENT for table `high_scores`
--
ALTER TABLE `high_scores`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2945;
--
-- AUTO_INCREMENT for table `parameters`
--
ALTER TABLE `parameters`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;
--
-- AUTO_INCREMENT for table `planets`
--
ALTER TABLE `planets`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1601;
--
-- AUTO_INCREMENT for table `planet_names`
--
ALTER TABLE `planet_names`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;
--
-- AUTO_INCREMENT for table `ship`
--
ALTER TABLE `ship`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `tradegoods`
--
ALTER TABLE `tradegoods`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
